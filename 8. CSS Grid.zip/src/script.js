var span = document.getElementsByClassName("close1")[0];
var gray = document.getElementsByClassName("gray")[0];
span.onclick = function() {
	gray.style.display = "none";
}

var email = document.getElementById('email');
var error = document.getElementsByClassName('error')[0];
var regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
email.addEventListener('input', function() {
 if (regexEmail.test(email.value)) {
    error.style.display = 'none';
    email.style.border = '#4A4A4A';
    email.style.color = '#FFFFFF';
 } else {
    error.style.display = 'block';
	email.style.border = '1px solid #F06666';
    email.style.color = '#CACACA';
 }
});

var contacts_name = document.getElementById('contacts_name');
var error_name = document.getElementsByClassName('error_name')[0];
var regexName = /^[A-ZА-ЯЁ]+$/i;
contacts_name.addEventListener('input', function() {
 if (regexName.test(contacts_name.value)) {
	error_name.style.display = 'none';
	contacts_name.style.border = '1px solid #E9E9E9';
	contacts_name.style.color = '#202020';
 } else {
	error_name.style.display = 'block';
	contacts_name.style.border = '1px solid #FF3030';
	contacts_name.style.color = '#202020';
 }
});

var contacts_email = document.getElementById('contacts_email');
var error_email = document.getElementsByClassName('error_email')[0];
contacts_email.addEventListener('input', function() {
 if (regexEmail.test(contacts_email.value)) {
	error_email.style.display = 'none';
	contacts_email.style.border = '1px solid #E9E9E9';
	contacts_email.style.color = '#202020';
 } else {
	error_email.style.display = 'block';
	contacts_email.style.border = '1px solid #FF3030';
	contacts_email.style.color = '#202020';
 }
});
